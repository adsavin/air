<?php

return array(
  'logout' => 'ອອກຈາກລະບົບ'
);

?>